# Smart_Door_Bell_Project

I led a team of four students in creating a cutting-edge Python 3.2-based Smart doorbell. Our project boasts an impressive feature set, including the ability to accurately identify the individual in the image and relay a voice announcement to the homeowner by cross-referencing data from a non-relational database. In addition, we seamlessly integrated our project with the AWS cloud and successfully deployed it as a fully-functional model in our classroom.
